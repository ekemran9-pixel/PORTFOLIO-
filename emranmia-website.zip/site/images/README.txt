PHOTOS FOR THE SITE  /  সাইটের ছবি
===================================

Gallery photos — put JPG files here with these exact names:

  1.jpg  Rotary dryer — Ma'aden
  2.jpg  Process piping fit-up
  3.jpg  30,000 sq ft steel building
  4.jpg  ETP installation
  5.jpg  Toilet Cleaner & Soap Plant
  6.jpg  ISO Clean Room
  7.jpg  Caustic Recovery Plant
  8.jpg  Workshop & CNC tool room
  9.jpg  Best Employee 2024 award

Any name that is missing simply shows "Photo pending" — nothing breaks.
Resize each one to about 1200 x 900 pixels and keep it under 400 KB.

Link preview image — og.jpg
  1200 x 630 pixels. This is what appears when the link is shared on
  WhatsApp, LinkedIn or Facebook. A site photo with your name on it works well.

App icons — icon-192.png and icon-512.png are already here.
  Replace them with your own if you want a different icon.
